
const message = "Hello World!"

function showAlert() {
    alert(`${message}`);
}
