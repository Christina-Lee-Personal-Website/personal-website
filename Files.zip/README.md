# personal-website

<!-- What the project does -->
This project provides Christina Lee's portfolio through HTML, CSS, and Javascript.
<!-- Why the project is useful -->
You can learn more about me, my interests, and my skillset and experience through my projects included in my portfolio.
